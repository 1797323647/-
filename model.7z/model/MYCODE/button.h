// button.h
#ifndef __BUTTON_H
#define __BUTTON_H

#include "stm32f10x.h"

void BUTTON_Init(void);
uint8_t BUTTON_Read(void);

#endif
