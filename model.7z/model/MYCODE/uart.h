#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include <stdint.h>
void uart_init(uint32_t bound);
#endif
